import React from "react";
import CourseRegistration from "./frontend/CourseRegistration";
import RegisteredCourses from "./frontend/RegisteredCourses";


const App = () => {
  const studentId = 123; // Example student ID

  return (
    <div>
      <h1>Course Registration System</h1>
      <CourseRegistration studentId={studentId} />
      <RegisteredCourses studentId={studentId} />
    </div>
  );
};

export default App;

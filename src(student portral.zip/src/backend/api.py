from flask import Flask, request, jsonify
import pyodbc

app = Flask(__name__)

# Database connection setup
def get_connection():
    return pyodbc.connect(
        'DRIVER={ODBC Driver 17 for SQL Server};'
        'SERVER=DESKTOP-ULD5VID\MSSQLSERVER2024;'  # Your SQL Server instance (change it accordingly)
        'DATABASE=DBMSProject;'  # Replace with your database name
        'Trusted_Connection=yes;'  # Use Windows Authentication (or set SQL authentication)
    )

# Endpoint to fetch all courses
@app.route('/api/courses', methods=['GET'])
def get_courses():
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT CourseID, Name FROM Course")  # Assuming the course table is named 'Course'
    courses = cursor.fetchall()
    conn.close()
    
    # Convert rows into a list of dictionaries
    courses_list = [{"CourseID": row[0], "Name": row[1]} for row in courses]
    return jsonify(courses_list)

# Endpoint to register courses for a student
@app.route('/api/register_course', methods=['POST'])
def register_course():
    data = request.json
    student_id = data.get('student_id')
    course_ids = data.get('course_ids')
    
    if not student_id or not course_ids:
        return jsonify({"message": "Invalid data, student_id and course_ids are required"}), 400
    
    conn = get_connection()
    cursor = conn.cursor()
    
    # Insert course registrations into the 'StudentCourse' table (or whatever table you're using)
    for course_id in course_ids:
        cursor.execute("INSERT INTO StudentCourse (StudentID, CourseID) VALUES (?, ?)", (student_id, course_id))
    
    conn.commit()
    conn.close()
    
    return jsonify({"message": "Courses registered successfully!"}), 201

# Endpoint to fetch all registered courses for a student
@app.route('/api/student_courses/<int:student_id>', methods=['GET'])
def get_student_courses(student_id):
    conn = get_connection()
    cursor = conn.cursor()
    
    # Fetch courses registered by the student
    cursor.execute("""
        SELECT c.CourseID, c.Name 
        FROM Course c 
        JOIN StudentCourse sc ON c.CourseID = sc.CourseID 
        WHERE sc.StudentID = ?
    """, (student_id,))
    
    courses = cursor.fetchall()
    conn.close()
    
    # Convert rows into a list of dictionaries
    registered_courses = [{"CourseID": row[0], "Name": row[1]} for row in courses]
    return jsonify(registered_courses)

if __name__ == "__main__":
   app.run(debug=True, port=8000)


import axios from 'axios';

// Base URL of the Flask backend
const API_BASE_URL = "http://127.0.0.1:8000/api";
axios.get("http://localhost:3000/test")
  .then(response => {
    console.log(response.data); 
     // Should log: { message: "Flask is running!" }
  })
  .catch(error => {
    console.error("Error connecting to Flask:", error);
  });

// Fetch all courses
export const fetchCourses = async () => {
  const response = await axios.get(`${API_BASE_URL}/courses`);
  return response.data; // Return the course data
};

// Register a course for a student
export const registerCourse = async (studentId, courseIds) => {
  const response = await axios.post(`${API_BASE_URL}/register_course`, {
    student_id: studentId,
    course_ids: courseIds,
  });
  return response.data; // Return success or error message
};

// Fetch registered courses for a student
export const fetchStudentCourses = async (studentId) => {
  const response = await axios.get(`${API_BASE_URL}/student_courses/${studentId}`);
  return response.data; // Return registered courses
};

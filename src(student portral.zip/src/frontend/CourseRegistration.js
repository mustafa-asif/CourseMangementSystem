import React, { useState, useEffect } from "react";
import axios from "axios";

const CourseRegistration = ({ studentId, onRegister }) => {
  const [courses, setCourses] = useState([]);
  const [selectedCourses, setSelectedCourses] = useState([]);

  // Fetch available courses
  useEffect(() => {
    axios.get("http://127.0.0.1:8000/api/courses")
      .then((response) => setCourses(response.data))
      .catch((error) => console.error("Error fetching courses:", error));
  }, []);
  useEffect(() => {
    axios.get("http://127.0.0.1:8000/api/courses")
      .then((response) => {
        console.log("Fetched courses:", response.data); // Debug
        setCourses(response.data);
      })
      .catch((error) => {
        console.error("Error fetching courses:", error); // Debug
      });
  }, []);
  
  // Handle checkbox selection
  const handleCheckboxChange = (courseId) => {
    setSelectedCourses((prev) =>
      prev.includes(courseId)
        ? prev.filter((id) => id !== courseId)
        : [...prev, courseId]
    );
  };

  // Register selected courses
  const handleRegister = () => {
    selectedCourses.forEach((courseId) => {
      axios.post("http://127.0.0.1:8000/api/register_course", {
        student_id: studentId,
        course_id: courseId,
      })
        .then(() => {
          console.log(`Course ${courseId} registered successfully`);
          onRegister(); // Refresh registered courses
        })
        .catch((error) => console.error("Error registering course:", error));
        
    });
    setSelectedCourses([]);
  };

  return (
    <div className="course-registration">
      <h2>Select Courses</h2>
      <form>{courses.length > 0 ? (
  courses.map((course) => (
    <div key={course.CourseID}>
      <label>
        <input
          type="checkbox"
          value={course.CourseID}
          checked={selectedCourses.includes(course.CourseID)}
          onChange={() => handleCheckboxChange(course.CourseID)}
        />
        {course.Name}
      </label>
    </div>
  ))
) : (
  <p>No courses available</p>
)}

        <button type="button" onClick={handleRegister}>
          Register Courses
        </button>
      </form>
    </div>
  );
};

export default CourseRegistration;

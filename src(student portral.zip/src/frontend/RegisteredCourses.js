import React, { useState, useEffect } from "react";
import axios from "axios";

const RegisteredCourses = ({ studentId }) => {
  const [registeredCourses, setRegisteredCourses] = useState([]);

  // Fetch registered courses
  const fetchRegisteredCourses = () => {
    axios
      .get(`http://127.0.0.1:8000/api/student_courses/${studentId}`)
      .then((response) => setRegisteredCourses(response.data))
      .catch((error) => console.error("Error fetching registered courses:", error));
  };

  useEffect(() => {
    fetchRegisteredCourses();
  }, );

  return (
    <div className="registered-courses">
      <h2>Your Registered Courses</h2>
      <ul>
        {registeredCourses.map((course) => (
          <li key={course.CourseID}>{course.Name}</li>
        ))}
      </ul>
      <button onClick={fetchRegisteredCourses}>Refresh</button>
    </div>
  );
};
export default RegisteredCourses;

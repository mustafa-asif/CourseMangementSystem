from flask import Flask, jsonify, request
from flask_cors import CORS
import pyodbc

app = Flask(__name__)
CORS(app)

# Database connection
def get_connection():
    return pyodbc.connect(
        'DRIVER={ODBC Driver 17 for SQL Server};'
        'SERVER=MUSTAFA;'  # Your SQL Server instance
        'DATABASE=DBMSProject;'  # Replace with your database name
        'Trusted_Connection=yes;'  # Uses Windows Authentication
    )

# Fetch all courses
@app.route('/api/courses', methods=['GET'])
def fetch_courses():
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM Course")
    rows = cursor.fetchall()
    conn.close()
    courses = [
        {
            "CourseID": row[0],
            "CourseName": row[1],
            "CreditHrTh": row[2],
            "CreditHrLab": row[3],
            "ProgID": row[4],
            "SemID": row[5]
        }
        for row in rows
    ]
    return jsonify(courses)

# Add a new course
@app.route('/api/courses', methods=['POST'])
def add_course():
    data = request.json
    course_id =  data.get('course_id')
    name = data.get('name')
    credit_hr_th = data.get('credit_hr_th')
    credit_hr_lab = data.get('credit_hr_lab')
    prog_id = data.get('prog_id')
    sem_id = data.get('sem_id')
    
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute(
        "INSERT INTO Course (CourseID,CourseName, CreditHrTh, CreditHrLab, ProgID, SemID) VALUES (?, ?, ?, ?, ?)",
        (course_id, name, credit_hr_th, credit_hr_lab, prog_id, sem_id)
    )
    conn.commit()
    conn.close()
    
    return jsonify({"message": "Course added successfully!"}), 201

# Delete a course
@app.route('/api/courses/<int:course_id>', methods=['DELETE'])
def delete_course(course_id):
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("DELETE FROM Course WHERE CourseID = ?", (course_id,))
    conn.commit()
    conn.close()
    return jsonify({"message": "Course deleted successfully!"})

# Fetch all students
@app.route('/api/students', methods=['GET'])
def fetch_students():
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM Student")
    rows = cursor.fetchall()
    conn.close()
    students = [
        {
            "StudentID": row[0],
            "StudentName": row[1],
            "DOB": row[2],
            "Address": row[3],
            "Phone": row[4],
            "CourseID": row[5],
            "ProgID": row[6],
            "SemID": row[7]
        }
        for row in rows
    ]
    return jsonify(students)

# Add a new student
@app.route('/api/students', methods=['POST'])
def add_student():
    data = request.json
    student_id = data.get('student_id')
    name = data.get('name')
    dob = data.get('dob')
    address = data.get('address')
    phone = data.get('phone')
    course_id = data.get('course_id')
    prog_id = data.get('prog_id')
    sem_id = data.get('sem_id')
    
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute(
        "INSERT INTO Student (StudentID,StudentName, DOB, Address, Phone, CourseID, ProgID, SemID) VALUES (?, ?, ?, ?, ?, ?, ?)",
        (name, dob, address, phone, course_id, prog_id, sem_id)
    )
    conn.commit()
    conn.close()
    
    return jsonify({"message": "Student added successfully!"}), 201

# Update an existing student
@app.route('/api/students/<int:student_id>', methods=['PUT'])
def update_student(student_id):
    data = request.json
    name = data.get('name')
    dob = data.get('dob')
    address = data.get('address')
    phone = data.get('phone')
    course_id = data.get('course_id')
    prog_id = data.get('prog_id')
    sem_id = data.get('sem_id')
    
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute(
        "UPDATE Student SET StudentName = ?, DOB = ?, Address = ?, Phone = ?, CourseID = ?, ProgID = ?, SemID = ? WHERE StudentID = ?", 
        (name, dob, address, phone, course_id, prog_id, sem_id, student_id)
    )
    conn.commit()
    conn.close()
    
    return jsonify({"message": f"Student {student_id} updated successfully!"})

# Delete a student
@app.route('/api/students/<int:student_id>', methods=['DELETE'])
def delete_student(student_id):
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("DELETE FROM Student WHERE StudentID = ?", (student_id,))
    conn.commit()
    conn.close()
    return jsonify({"message": "Student deleted successfully!"})


# Fetch all teachers
@app.route('/api/teachers', methods=['GET'])
def fetch_teachers():
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM Teacher")
    rows = cursor.fetchall()
    conn.close()
    teachers = [
        {
            
            "TeacherID": row[0],
            "TeacherName": row[1],
            "DOJ": row[2],
            "Status": row[3],
            "Salary": row[4],
            "Job": row[5],
            "CourseID": row[6]
        }
        for row in rows
    ]
    return jsonify(teachers)

# Add a new teacher
@app.route('/api/teachers', methods=['POST'])
def add_teacher():
    data = request.json
    teacher_id = data.get('teacher_id')
    name = data.get('name')
    doj = data.get('doj')  # Date of Joining
    status = data.get('status')
    salary = data.get('salary')
    job = data.get('job')
    course_id = data.get('course_id')
    sem_id = data.get('sem_id')  # Semester ID
    prog_id = data.get('prog_id')  # Program ID

    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute(
        "INSERT INTO Teacher (TeacherID, TeacherName, DOJ, Status, Salary, Job, CourseID, SemID, ProgID) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)",
        (teacher_id, name, doj, status, salary, job, course_id, sem_id, prog_id)
    )
    conn.commit()
    conn.close()
    
    return jsonify({"message": "Teacher added successfully!"}), 201

# Update an existing teacher
@app.route('/api/teachers/<int:teacher_id>', methods=['PUT'])
def update_teacher(teacher_id):
    data = request.json
    course_id = data.get('course_id')
    name = data.get('name')
    doj = data.get('doj')
    status = data.get('status')
    salary = data.get('salary')
    job = data.get('job')
    
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute(
        "UPDATE Teacher SET TeacherName = ?, DOJ = ?, Status = ?, Salary = ?, Job = ?,  CourseID = ? WHERE TeacherID = ?", 
        (name, doj, status, salary, job, course_id, teacher_id)
    )
    conn.commit()
    conn.close()
    
    return jsonify({"message": f"Teacher {teacher_id} updated successfully!"})

# Delete a teacher
@app.route('/api/teachers/<int:teacher_id>', methods=['DELETE'])
def delete_teacher(teacher_id):
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("DELETE FROM Teacher WHERE TeacherID = ?", (teacher_id,))
    conn.commit()
    conn.close()
    return jsonify({"message": "Teacher deleted successfully!"})

if __name__ == "__main__":
    app.run(debug=True, port=5500)


from flask import Flask, jsonify, request
from flask_cors import CORS
import pyodbc

app = Flask(__name__)
CORS(app)

# Database connection
def get_connection():
    return pyodbc.connect(
        'DRIVER={ODBC Driver 17 for SQL Server};'
        'SERVER=DESKTOP-ULD5VID\\MSSQLSERVER2024;'  # Your SQL Server instance
        'DATABASE=DBMSProject;'  # Replace with your database name
        'Trusted_Connection=yes;'  # Uses Windows Authentication
    )

# Get courses and register courses
@app.route('/api/courses', methods=['GET', 'POST'])
def courses():
    conn = get_connection()
    cursor = conn.cursor()
    
    if request.method == 'GET':
        # Fetch all courses from the Course table
        cursor.execute("SELECT CourseID, Name FROM Course")
        rows = cursor.fetchall()
        conn.close()
        
        # Return courses as JSON
        courses = [{"CourseID": row[0], "Name": row[1]} for row in rows]
        return jsonify(courses)
    
    elif request.method == 'POST':
        # Register courses for a student
        data = request.json
        student_id = data.get('student_id')
        course_ids = data.get('course_ids')  # List of selected course IDs
        
        if not student_id or not course_ids:
            return jsonify({"message": "Student ID and Course IDs are required!"}), 400

        registered_courses = []

        try:
            for course_id in course_ids:
                # Check if the student is already registered for the course
                cursor.execute(
                    "SELECT * FROM StudentCourse WHERE StudentID = ? AND CourseID = ?",
                    (student_id, course_id)
                )
                if cursor.fetchone():
                    continue  # Skip if already registered
                
                # Register the student for the course
                cursor.execute(
                    "INSERT INTO StudentCourse (StudentID, CourseID) VALUES (?, ?)",
                    (student_id, course_id)
                )
                registered_courses.append(course_id)

            conn.commit()
            return jsonify({
                "message": "Student registered for courses successfully!",
                "registered_courses": registered_courses
            }), 201
        except Exception as e:
            conn.rollback()
            return jsonify({"message": f"Error registering courses: {str(e)}"}), 500
        finally:
            conn.close()

# View student-course registrations
@app.route('/api/view_student_courses', methods=['GET'])
def view_student_courses():
    conn = get_connection()
    cursor = conn.cursor()
    
    # Query to get student information and their registered courses
    cursor.execute("""
        SELECT 
            Student.StudentID, 
            Student.Name AS StudentName,
            Course.CourseID, 
            Course.Name AS CourseName,
            Course.CreditHoursTheory, 
            Course.CreditHoursLab
        FROM 
            Student
        INNER JOIN 
            StudentCourse ON Student.StudentID = StudentCourse.StudentID
        INNER JOIN 
            Course ON StudentCourse.CourseID = Course.CourseID
        ORDER BY Student.StudentID
    """)
    rows = cursor.fetchall()
    conn.close()
    
    # Group courses by student ID
    student_courses = {}
    for row in rows:
        student_id = row[0]
        student_name = row[1]
        course_details = {
            "CourseID": row[2],
            "CourseName": row[3],
            "CreditHoursTheory": row[4],
            "CreditHoursLab": row[5]
        }
        if student_id not in student_courses:
            student_courses[student_id] = {
                "StudentName": student_name,
                "Courses": []
            }
        student_courses[student_id]["Courses"].append(course_details)
    
    # Convert to a list for JSON response
    result = [
        {
            "StudentID": student_id,
            "StudentName": student_info["StudentName"],
            "Courses": student_info["Courses"]
        }
        for student_id, student_info in student_courses.items()
    ]
    
    return jsonify(result)


if __name__ == "__main__":
    app.run(debug=True, port=5500)
